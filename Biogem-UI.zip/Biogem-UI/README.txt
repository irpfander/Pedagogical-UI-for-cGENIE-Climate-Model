# Biogem-UI

This project is an interactive user interface for the BIOGEM components of the cGENIE model. It was created to aid undergraduates in using and understanding the climate model. It is built in MATLAB from muffin-plot master by Andy Ridgwell (derpycode).

File Structure
BiogemApp.mlapp : the UI script
UI_biogem_2d.m : altered plot_fields_biogem_2d.m to be compatible with UI
UI_biogem_3d_k.m : altered plot_fields_biogem_3d_k.m to be compatible with UI
UI_biogem_3d_i.m : altered plot_fields_biogem_3d_i.m to be compatible with UI
UI_crossplotc.m : altered plot_crossplotc.m to be compatible with UI
UI_histc_2d.m : altered plot_histc_2d.m to be compatible with UI

Using the interface:
- Download the Biogem-UI folder
- Run BiogemApp.mlapp with MATLAB after adding your experiment folder (with netCDF file) into the same folder


Contribution: To contribute to this project contact Isabelle Pfander (irpfander) on Github
Credits: Andy Ridgwell (derpycode) muffinplot 
Prerequisite: MATLAB - built with R2019 (9.6.0.1174912)
